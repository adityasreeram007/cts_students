from django.shortcuts import render
from pymongo import MongoClient
mongo=MongoClient("mongodb://localhost:27017/")
# Create your views here.
user=''
def login(request):
    return render(request,'login.html')

def homepage(request):
    if(request.method=="POST"):
        #print(request.POST)
        findpass=mongo.ctsauth.login.find({'username':request.POST['username']})
        flag=0
        #print(findpass)
        user=request.POST['username']
        print(user)
        passcheck=''
        for j in findpass:
            if(j['username']==request.POST['username']):
                flag=1
                passcheck=j['password']
        if(passcheck==request.POST['password']):
            return render(request,'homepage.html')
        return render(request,'login.html')
def addmsg(request):
    print('c')
    if( request.method=="POST"):
        print('o')
        x=mongo.ctsauth.messages.insert({'user':"admin",'message':request.POST['msg']})
        find=mongo.ctsauth.messages.find()
        sendr=[]
        
        for i in find:
            d={}
            d[i['user']]=i['message']
            sendr.append(d)
            
        return render(request,'chatbox.html',{'messages':sendr})
    
    
def chatbox(request):
    find=mongo.ctsauth.messages.find()
    print(user)
    sendr=[]
    
    for i in find:
        d={}
        d[i['user']]=i['message']
        sendr.append(d)
        
    return render(request,'chatbox.html',{'messages':sendr})
    