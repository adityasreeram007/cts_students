from django.apps import AppConfig


class CtsSiteConfig(AppConfig):
    name = 'cts_site'
